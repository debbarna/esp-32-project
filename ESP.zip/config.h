#pragma once

// ==================== PIN MAPPING (ESP32) ====================
// Relays are assumed ACTIVE-HIGH (most opto-isolated relay boards are
// active-LOW -- check yours and flip RELAY_ON/RELAY_OFF below if needed).

#define PIN_RELAY_INLET_VALVE   25   // solenoid water inlet valve
#define PIN_RELAY_DRAIN_PUMP    26
#define PIN_RELAY_MOTOR_CW      27   // wash motor - clockwise direction
#define PIN_RELAY_MOTOR_CCW     14   // wash motor - counter-clockwise direction
#define PIN_RELAY_DOOR_LOCK     12   // energize to lock door
#define PIN_RELAY_HEATER        13   // optional water heater
#define PIN_BUZZER              33

// Sensors
#define PIN_WATER_LEVEL_ANALOG  34   // pressure sensor / pressostat, analog out
#define PIN_DOOR_SWITCH         35   // digital, LOW = door closed (pull-up)
#define PIN_NTC_TEMP            32   // analog thermistor for water temp (optional)

// Front panel (simple version - 3 buttons + start LED)
#define PIN_BTN_START_PAUSE     16
#define PIN_BTN_CYCLE_SELECT    17
#define PIN_LED_RUNNING         4

// ==================== RELAY LOGIC ====================
#define RELAY_ON  HIGH
#define RELAY_OFF LOW

// ==================== WATER LEVEL ====================
// Calibrate against your actual pressure sensor / float switch stack.
// Values are raw ADC (0-4095 on ESP32, 12-bit).
#define WATER_LEVEL_EMPTY   200
#define WATER_LEVEL_LOW     1200   // enough to cover clothes lightly
#define WATER_LEVEL_HIGH    2600   // full wash level
#define WATER_LEVEL_OVERFLOW 3800  // safety cutoff - force drain immediately

// ==================== MOTOR / AGITATION TIMING ====================
#define AGITATE_ON_MS   4000    // spin this direction...
#define AGITATE_OFF_MS  500     // ...pause...
#define AGITATE_REVERSE_MS 4000 // ...then reverse

// Spin (final extraction) speed profile - ramp handled by duty cycling
// relay on/off rapidly is NOT safe for AC induction motors; if your motor
// driver supports PWM/VFD speed control, use that instead of relay bang-bang.
#define SPIN_DURATION_MS   (60UL * 1000UL)   // 60s spin cycle

// ==================== CYCLE STAGE DURATIONS ====================
// These are defaults for the "Normal" cycle. See cycle_profiles in
// state_machine.h for per-cycle-type overrides (Quick, Heavy, Delicate).
#define FILL_TIMEOUT_MS      (5UL * 60UL * 1000UL)  // 5 min max to fill, else fault
#define WASH_DURATION_MS     (15UL * 60UL * 1000UL) // 15 min wash agitation
#define DRAIN_TIMEOUT_MS     (3UL * 60UL * 1000UL)  // 3 min max to drain, else fault
#define RINSE_DURATION_MS    (8UL * 60UL * 1000UL)  // 8 min rinse agitation
#define NUM_RINSES           2

// ==================== SAFETY ====================
#define DOOR_MUST_BE_CLOSED_TO_RUN true
#define MAX_HEATER_TEMP_C 60.0f     // cut heater above this, safety
