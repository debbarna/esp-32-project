/*
 * ESP32 Washing Machine Controller
 *
 * Non-blocking state machine driving a full wash cycle:
 * FILL -> WASH (agitate) -> DRAIN -> [RINSE_FILL -> RINSE_AGITATE ->
 * RINSE_DRAIN] x N -> SPIN -> DONE
 *
 * Safety: door-closed interlock enforced during any active cycle,
 * overflow cutoff via water level sensor, fill/drain timeouts trigger a
 * fault state that requires manual acknowledgement to clear.
 *
 * Controls (see config.h for pins):
 *   - Start/Pause button: start cycle / pause+resume / ack fault or done
 *   - Cycle Select button: cycles Quick -> Normal -> Heavy -> Delicate (idle only)
 */

#include <Arduino.h>
#include "config.h"
#include "state_machine.h"

WashingMachine washer;

void setup() {
    Serial.begin(115200);
    delay(300);
    Serial.println("Washing machine controller booting...");
    washer.begin();
    Serial.println("Ready. Press Start/Pause to begin.");
}

void loop() {
    washer.update();
    delay(20); // small loop delay; all timing is millis()-based so this is safe
}
