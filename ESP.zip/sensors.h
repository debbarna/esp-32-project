#pragma once
#include <Arduino.h>
#include "config.h"

class Sensors {
public:
    void begin() {
        pinMode(PIN_DOOR_SWITCH, INPUT_PULLUP);
        pinMode(PIN_BTN_START_PAUSE, INPUT_PULLUP);
        pinMode(PIN_BTN_CYCLE_SELECT, INPUT_PULLUP);
        // ESP32 ADC pins need no pinMode for analogRead
    }

    int waterLevelRaw() {
        return analogRead(PIN_WATER_LEVEL_ANALOG);
    }

    bool waterAtLeast(int threshold) {
        return waterLevelRaw() >= threshold;
    }

    bool waterOverflow() {
        return waterLevelRaw() >= WATER_LEVEL_OVERFLOW;
    }

    bool doorClosed() {
        return digitalRead(PIN_DOOR_SWITCH) == LOW; // pulled low when closed
    }

    // Simple NTC thermistor read -> approximate Celsius.
    // Replace with your thermistor's actual Beta/R25 values as needed.
    float waterTempC() {
        int raw = analogRead(PIN_NTC_TEMP);
        if (raw <= 0) return 20.0f; // sane fallback
        float voltage = raw * (3.3f / 4095.0f);
        // Placeholder linear approximation - swap for a proper
        // Steinhart-Hart calc once you've characterized your thermistor.
        float tempC = (voltage - 0.5f) * 100.0f;
        return constrain(tempC, 0.0f, 100.0f);
    }

    bool startPauseButtonPressed() {
        return digitalRead(PIN_BTN_START_PAUSE) == LOW;
    }

    bool cycleSelectButtonPressed() {
        return digitalRead(PIN_BTN_CYCLE_SELECT) == LOW;
    }
};
