#pragma once
#include <Arduino.h>
#include "config.h"

enum MotorDir { MOTOR_STOP, MOTOR_CW, MOTOR_CCW };

class Actuators {
public:
    void begin() {
        pinMode(PIN_RELAY_INLET_VALVE, OUTPUT);
        pinMode(PIN_RELAY_DRAIN_PUMP, OUTPUT);
        pinMode(PIN_RELAY_MOTOR_CW, OUTPUT);
        pinMode(PIN_RELAY_MOTOR_CCW, OUTPUT);
        pinMode(PIN_RELAY_DOOR_LOCK, OUTPUT);
        pinMode(PIN_RELAY_HEATER, OUTPUT);
        pinMode(PIN_BUZZER, OUTPUT);
        pinMode(PIN_LED_RUNNING, OUTPUT);
        allOff();
    }

    void allOff() {
        valve(false);
        drainPump(false);
        motor(MOTOR_STOP);
        heater(false);
        buzzer(false);
        // NOTE: door lock intentionally left alone here - unlockDoor()
        // must be called explicitly, never implicitly via allOff().
    }

    void valve(bool on) {
        digitalWrite(PIN_RELAY_INLET_VALVE, on ? RELAY_ON : RELAY_OFF);
    }

    void drainPump(bool on) {
        digitalWrite(PIN_RELAY_DRAIN_PUMP, on ? RELAY_ON : RELAY_OFF);
    }

    // Enforces break-before-make: never energize both directions at once.
    void motor(MotorDir dir) {
        digitalWrite(PIN_RELAY_MOTOR_CW, RELAY_OFF);
        digitalWrite(PIN_RELAY_MOTOR_CCW, RELAY_OFF);
        if (dir == MOTOR_CW) {
            delay(50); // brief dead time before reversing direction
            digitalWrite(PIN_RELAY_MOTOR_CW, RELAY_ON);
        } else if (dir == MOTOR_CCW) {
            delay(50);
            digitalWrite(PIN_RELAY_MOTOR_CCW, RELAY_ON);
        }
    }

    void lockDoor() {
        digitalWrite(PIN_RELAY_DOOR_LOCK, RELAY_ON);
    }

    void unlockDoor() {
        digitalWrite(PIN_RELAY_DOOR_LOCK, RELAY_OFF);
    }

    void heater(bool on) {
        digitalWrite(PIN_RELAY_HEATER, on ? RELAY_ON : RELAY_OFF);
    }

    void buzzer(bool on) {
        digitalWrite(PIN_BUZZER, on ? HIGH : LOW);
    }

    void runningLED(bool on) {
        digitalWrite(PIN_LED_RUNNING, on ? HIGH : LOW);
    }

    // Short beep pattern for cycle-complete / fault notification.
    void beepPattern(int times, int onMs = 200, int offMs = 150) {
        for (int i = 0; i < times; i++) {
            buzzer(true);
            delay(onMs);
            buzzer(false);
            if (i < times - 1) delay(offMs);
        }
    }
};
