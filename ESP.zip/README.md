# ESP32 Washing Machine Controller

Non-blocking state-machine firmware for a wall-powered washing machine:
fill, agitate wash, drain, rinse (repeated), spin, done. Includes
safety interlocks (door lock, overflow cutoff, fill/drain timeouts).

## Structure

```
firmware/
  config.h          # Pin mapping, water level thresholds, timing constants
  actuators.h        # Relay control: valve, drain pump, motor (CW/CCW), door lock, heater, buzzer
  sensors.h          # Water level (analog), door switch, temp (NTC), buttons
  state_machine.h     # Non-blocking FSM: FILL -> WASH -> DRAIN -> RINSE(xN) -> SPIN -> DONE
  main.cpp             # Entry point
```

## ⚠️ Important safety note

**This is a control-logic reference, not a certified appliance design.**
Mains-voltage motors, heaters, and water valves involve real electrical
and flood risk. Before running this on real hardware:

- Use appropriately rated relays/contactors for your motor's actual
  current draw (a wash motor is NOT a small DC hobby motor — most are
  AC induction motors needing a contactor, not a logic-level relay).
- Add a hardware-level overflow failsafe (mechanical float switch cutting
  power to the inlet valve) independent of the ESP32 — never rely on
  software alone to prevent flooding.
- Add a physical door interlock switch that cuts motor power directly,
  not just a software check, so a frozen/crashed microcontroller can't
  spin the drum with the door open.
- The spin-cycle motor control in `state_machine.h` is a **placeholder**
  — real spin cycles need a motor driver with proper speed ramping (VFD
  or PWM-capable driver), not relay bang-bang, to avoid mechanical shock,
  belt damage, or inrush current issues.

## Wall-powered relay wiring

All actuators (valve solenoid, drain pump, motor, heater) are mains or
higher-current loads — the ESP32 GPIOs drive relay/contactor **coils**,
not the loads directly. Use opto-isolated relay modules and keep mains
wiring physically separated from the ESP32 and low-voltage sensor wiring.

## Cycle profiles

Defined in `state_machine.h` as `CYCLE_PROFILES`:

| Cycle | Wash | Rinse | Spin | Rinses | Heater |
|---|---|---|---|---|---|
| Quick | 5 min | 3 min | 30s | 1 | No |
| Normal | 15 min | 8 min | 60s | 2 | No |
| Heavy | 25 min | 10 min | 90s | 3 | Yes |
| Delicate | 8 min | 6 min | 20s | 1 | No |

Cycle-select button cycles through these while in `ST_IDLE`.

## Calibration

1. **Water level thresholds** (`WATER_LEVEL_EMPTY/LOW/HIGH/OVERFLOW` in
   `config.h`) — these are raw ADC values (0–4095 on ESP32's 12-bit ADC).
   Calibrate against your actual pressure sensor / pressostat by logging
   raw values at known water levels.
2. **Agitation timing** (`AGITATE_ON_MS`, `AGITATE_OFF_MS`,
   `AGITATE_REVERSE_MS`) — tune to your motor/gearbox; too-fast direction
   reversal without the `AG_PAUSE` dead-time will stress the motor and
   contactors.
3. **NTC thermistor curve** — `sensors.h` `waterTempC()` uses a placeholder
   linear approximation. Replace with a proper Steinhart-Hart calculation
   using your thermistor's actual Beta and R25 values for accurate heater
   cutoff behavior.

## State machine flow

```
IDLE --(start button, door closed)--> FILL
FILL --(water high OR timeout->FAULT)--> WASH
WASH --(duration elapsed)--> DRAIN
DRAIN --(empty OR timeout->FAULT)--> RINSE_FILL (if rinses remain) or SPIN
RINSE_FILL -> RINSE_AGITATE -> RINSE_DRAIN --(repeat per profile.numRinses)--> SPIN
SPIN --(duration elapsed)--> DONE
DONE --(start button pressed)--> IDLE

Any active state --(door opens OR overflow)--> FAULT
FAULT --(start button = manual reset)--> IDLE
Any active state --(start/pause pressed)--> PAUSED --(resume)--> previous state
```

## Flashing

PlatformIO `platformio.ini`:
```ini
[env:esp32dev]
platform = espressif32
board = esp32dev
framework = arduino
monitor_speed = 115200
```

No external libraries required — pure Arduino core (`analogRead`,
`digitalRead/Write`, `millis()`).

## Suggested next steps for your portfolio

- Replace relay bang-bang spin control with PWM/VFD-driven speed ramping.
- Add a real button debounce routine (current edge-detection is fine for
  a demo but will double-trigger on noisy mechanical buttons).
- Add WiFi telemetry (cycle state, water level, temp) to a simple web
  dashboard — pairs well with your other ESP32 work.
- Persist selected cycle + fault history to NVS (ESP32 flash) so a power
  loss mid-cycle isn't silently forgotten.
