#pragma once
#include <Arduino.h>
#include "config.h"
#include "actuators.h"
#include "sensors.h"

enum WashState {
    ST_IDLE,
    ST_FILL,
    ST_WASH,
    ST_DRAIN,
    ST_RINSE_FILL,
    ST_RINSE_AGITATE,
    ST_RINSE_DRAIN,
    ST_SPIN,
    ST_DONE,
    ST_PAUSED,
    ST_FAULT
};

enum CycleType { CYCLE_QUICK, CYCLE_NORMAL, CYCLE_HEAVY, CYCLE_DELICATE, NUM_CYCLE_TYPES };

enum FaultCode {
    FAULT_NONE,
    FAULT_FILL_TIMEOUT,
    FAULT_DRAIN_TIMEOUT,
    FAULT_DOOR_OPEN,
    FAULT_OVERFLOW
};

struct CycleProfile {
    const char *name;
    unsigned long washDurationMs;
    unsigned long rinseDurationMs;
    unsigned long spinDurationMs;
    uint8_t numRinses;
    bool useHeater;
};

const CycleProfile CYCLE_PROFILES[NUM_CYCLE_TYPES] = {
    // name,       wash,                  rinse,                 spin,             rinses, heater
    { "Quick",     5UL*60UL*1000UL,       3UL*60UL*1000UL,       30UL*1000UL,      1,      false },
    { "Normal",    WASH_DURATION_MS,      RINSE_DURATION_MS,     SPIN_DURATION_MS, 2,      false },
    { "Heavy",     25UL*60UL*1000UL,      10UL*60UL*1000UL,      90UL*1000UL,      3,      true  },
    { "Delicate",  8UL*60UL*1000UL,       6UL*60UL*1000UL,       20UL*1000UL,      1,      false },
};

class WashingMachine {
public:
    Actuators actuators;
    Sensors sensors;

    WashState state = ST_IDLE;
    WashState stateBeforePause = ST_IDLE;
    CycleType selectedCycle = CYCLE_NORMAL;
    FaultCode fault = FAULT_NONE;

    unsigned long stateEnteredAt = 0;
    unsigned long agitatePhaseStartedAt = 0;
    uint8_t rinsesCompleted = 0;

    // Agitation sub-phase: cycles CW_ON -> PAUSE -> CCW_ON -> PAUSE -> repeat
    enum AgitatePhase { AG_CW_ON, AG_PAUSE_1, AG_CCW_ON, AG_PAUSE_2 };
    AgitatePhase agitatePhase = AG_CW_ON;

    void begin() {
        actuators.begin();
        sensors.begin();
        enterState(ST_IDLE);
    }

    // Call every loop() iteration. Non-blocking.
    void update() {
        handleButtons();
        checkSafety();  // runs every cycle regardless of state

        switch (state) {
            case ST_IDLE:          updateIdle();         break;
            case ST_FILL:          updateFill();          break;
            case ST_WASH:          updateWash();          break;
            case ST_DRAIN:         updateDrain();         break;
            case ST_RINSE_FILL:    updateRinseFill();     break;
            case ST_RINSE_AGITATE: updateRinseAgitate();  break;
            case ST_RINSE_DRAIN:   updateRinseDrain();    break;
            case ST_SPIN:          updateSpin();          break;
            case ST_DONE:          updateDone();          break;
            case ST_PAUSED:        /* waiting for resume via button */ break;
            case ST_FAULT:         /* waiting for manual reset */      break;
        }
    }

private:
    const CycleProfile &profile() { return CYCLE_PROFILES[selectedCycle]; }
    unsigned long elapsedInState() { return millis() - stateEnteredAt; }

    void enterState(WashState s) {
        state = s;
        stateEnteredAt = millis();
        Serial.print("State -> ");
        Serial.println(s);
    }

    // ---------------- Safety (checked every loop, any state) ----------------
    void checkSafety() {
        bool activeCycle = (state != ST_IDLE && state != ST_DONE &&
                             state != ST_FAULT && state != ST_PAUSED);

        if (activeCycle && sensors.waterOverflow()) {
            triggerFault(FAULT_OVERFLOW);
            return;
        }

        if (activeCycle && DOOR_MUST_BE_CLOSED_TO_RUN && !sensors.doorClosed()) {
            triggerFault(FAULT_DOOR_OPEN);
            return;
        }

        // Heater safety cutoff regardless of state
        if (sensors.waterTempC() > MAX_HEATER_TEMP_C) {
            actuators.heater(false);
        }
    }

    void triggerFault(FaultCode code) {
        fault = code;
        actuators.allOff();
        actuators.unlockDoor();
        actuators.runningLED(false);
        actuators.beepPattern(5, 100, 100);
        enterState(ST_FAULT);
    }

    // ---------------- Button handling ----------------
    void handleButtons() {
        static bool lastStartBtn = false;
        static bool lastSelectBtn = false;
        bool startBtn = sensors.startPauseButtonPressed();
        bool selectBtn = sensors.cycleSelectButtonPressed();

        // rising edge only (simple debounce via edge detect; add real
        // debounce delay in production if buttons are noisy)
        if (startBtn && !lastStartBtn) {
            onStartPausePressed();
        }
        if (selectBtn && !lastSelectBtn && state == ST_IDLE) {
            selectedCycle = (CycleType)((selectedCycle + 1) % NUM_CYCLE_TYPES);
            Serial.print("Cycle selected: ");
            Serial.println(profile().name);
        }
        lastStartBtn = startBtn;
        lastSelectBtn = selectBtn;
    }

    void onStartPausePressed() {
        if (state == ST_IDLE) {
            startCycle();
        } else if (state == ST_PAUSED) {
            resumeCycle();
        } else if (state == ST_FAULT) {
            resetFromFault();
        } else if (state == ST_DONE) {
            enterState(ST_IDLE);
        } else {
            pauseCycle();
        }
    }

    void startCycle() {
        if (!sensors.doorClosed()) {
            Serial.println("Cannot start - door open");
            actuators.beepPattern(2);
            return;
        }
        rinsesCompleted = 0;
        fault = FAULT_NONE;
        actuators.lockDoor();
        actuators.runningLED(true);
        enterState(ST_FILL);
    }

    void pauseCycle() {
        stateBeforePause = state;
        actuators.motor(MOTOR_STOP);
        actuators.valve(false);
        actuators.drainPump(false);
        enterState(ST_PAUSED);
    }

    void resumeCycle() {
        enterState(stateBeforePause);
    }

    void resetFromFault() {
        fault = FAULT_NONE;
        actuators.allOff();
        enterState(ST_IDLE);
    }

    // ---------------- Agitation helper (used by WASH and RINSE_AGITATE) ----
    // Non-blocking CW -> pause -> CCW -> pause -> repeat cycling.
    void runAgitation() {
        unsigned long phaseElapsed = millis() - agitatePhaseStartedAt;
        unsigned long phaseDuration;

        switch (agitatePhase) {
            case AG_CW_ON:   phaseDuration = AGITATE_ON_MS;      break;
            case AG_PAUSE_1: phaseDuration = AGITATE_OFF_MS;     break;
            case AG_CCW_ON:  phaseDuration = AGITATE_REVERSE_MS; break;
            default:         phaseDuration = AGITATE_OFF_MS;     break; // AG_PAUSE_2
        }

        if (phaseElapsed < phaseDuration) return; // still in current phase

        // advance to next phase
        switch (agitatePhase) {
            case AG_CW_ON:
                actuators.motor(MOTOR_STOP);
                agitatePhase = AG_PAUSE_1;
                break;
            case AG_PAUSE_1:
                actuators.motor(MOTOR_CCW);
                agitatePhase = AG_CCW_ON;
                break;
            case AG_CCW_ON:
                actuators.motor(MOTOR_STOP);
                agitatePhase = AG_PAUSE_2;
                break;
            default: // AG_PAUSE_2
                actuators.motor(MOTOR_CW);
                agitatePhase = AG_CW_ON;
                break;
        }
        agitatePhaseStartedAt = millis();
    }

    void startAgitation() {
        actuators.motor(MOTOR_CW);
        agitatePhase = AG_CW_ON;
        agitatePhaseStartedAt = millis();
    }

    // ---------------- State handlers ----------------
    void updateIdle() {
        actuators.runningLED(false);
    }

    void updateFill() {
        actuators.valve(true);
        if (sensors.waterAtLeast(WATER_LEVEL_HIGH)) {
            actuators.valve(false);
            if (profile().useHeater) actuators.heater(true);
            startAgitation();
            enterState(ST_WASH);
        } else if (elapsedInState() > FILL_TIMEOUT_MS) {
            triggerFault(FAULT_FILL_TIMEOUT);
        }
    }

    void updateWash() {
        runAgitation();
        if (elapsedInState() > profile().washDurationMs) {
            actuators.motor(MOTOR_STOP);
            actuators.heater(false);
            enterState(ST_DRAIN);
        }
    }

    void updateDrain() {
        actuators.drainPump(true);
        if (sensors.waterLevelRaw() <= WATER_LEVEL_EMPTY) {
            actuators.drainPump(false);
            if (rinsesCompleted < profile().numRinses) {
                enterState(ST_RINSE_FILL);
            } else {
                enterState(ST_SPIN);
            }
        } else if (elapsedInState() > DRAIN_TIMEOUT_MS) {
            triggerFault(FAULT_DRAIN_TIMEOUT);
        }
    }

    void updateRinseFill() {
        actuators.valve(true);
        if (sensors.waterAtLeast(WATER_LEVEL_HIGH)) {
            actuators.valve(false);
            startAgitation();
            enterState(ST_RINSE_AGITATE);
        } else if (elapsedInState() > FILL_TIMEOUT_MS) {
            triggerFault(FAULT_FILL_TIMEOUT);
        }
    }

    void updateRinseAgitate() {
        runAgitation();
        if (elapsedInState() > profile().rinseDurationMs) {
            actuators.motor(MOTOR_STOP);
            enterState(ST_RINSE_DRAIN);
        }
    }

    void updateRinseDrain() {
        actuators.drainPump(true);
        if (sensors.waterLevelRaw() <= WATER_LEVEL_EMPTY) {
            actuators.drainPump(false);
            rinsesCompleted++;
            if (rinsesCompleted < profile().numRinses) {
                enterState(ST_RINSE_FILL);
            } else {
                enterState(ST_SPIN);
            }
        } else if (elapsedInState() > DRAIN_TIMEOUT_MS) {
            triggerFault(FAULT_DRAIN_TIMEOUT);
        }
    }

    void updateSpin() {
        // NOTE: relay-driven bang-bang spin is a placeholder. Real spin
        // cycles need a motor driver with speed ramp (VFD or PWM-capable
        // driver) to avoid mechanical shock and excess current draw.
        // This just runs the motor one direction for the spin duration.
        if (elapsedInState() == 0) {
            actuators.motor(MOTOR_CW);
        }
        if (elapsedInState() > profile().spinDurationMs) {
            actuators.motor(MOTOR_STOP);
            actuators.unlockDoor();
            actuators.runningLED(false);
            actuators.beepPattern(3);
            enterState(ST_DONE);
        }
    }

    void updateDone() {
        // sits here until user presses start/pause to acknowledge and
        // return to idle (handled in onStartPausePressed)
    }
};
